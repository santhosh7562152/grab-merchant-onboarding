# Grab Merchant Onboarding – Requirements to Backlog

A Business Analyst portfolio project that turns a business problem into documented requirements, user stories and a Jira backlog.

> **Note:** This is a proposed portfolio case study. It is not an official Grab project. The interview answers, estimates and story points are assumptions, not actual Grab policies or data.

## Problem

Restaurant owners who want to join GrabFood must submit documents for manual verification. The sales team checks them by hand, which delays onboarding and gives limited visibility into application status.

## Goal

Design a simplified merchant onboarding workflow that helps the sales team verify documents, approve applications and onboard restaurants faster.

## My role

Business Analyst: gathered requirements (through a hypothetical stakeholder interview), mapped the process, wrote user stories with acceptance criteria, and planned the work in Jira.

## Tools used

Google Docs, Draw.io, Jira, Confluence/Notion

## Project structure

```
grab-merchant-onboarding/
├── README.md
├── documentation/
│   ├── project-overview.pdf
│   ├── stakeholder-interview.pdf
│   ├── business-requirements.pdf
│   └── user-stories.pdf
├── diagrams/
│   └── merchant-onboarding-flow.png
└── screenshots/
    ├── jira-backlog.png
    ├── sprint-1.png
    ├── sprint-2.png
    └── jira-board.png
```

## Deliverables

| Deliverable | File |
| --- | --- |
| Project overview, problem, objectives, scope, stakeholders | `documentation/project-overview.pdf` |
| Hypothetical sales executive interview and key findings | `documentation/stakeholder-interview.pdf` |
| Business requirements, process flow, traceability matrix, risks | `documentation/business-requirements.pdf` |
| 8 user stories, sprint plan, test scenarios | `documentation/user-stories.pdf` |
| Process flow diagram | `diagrams/merchant-onboarding-flow.png` |
| Jira backlog and sprint screenshots | `screenshots/` |

## Jira summary

- **Project key:** SANTA (8 user stories, SANTA-1 to SANTA-8)
- **Sprint 1 – Core Onboarding:** 6 stories, 16 story points
- **Sprint 2 – Additional Features:** 2 stories, 5 story points

| Key | Story | Priority | Points | Sprint |
| --- | --- | --- | --- | --- |
| SANTA-1 | Restaurant Registration | High | 3 | 1 |
| SANTA-2 | Restaurant Details Submission | High | 2 | 1 |
| SANTA-3 | Document Upload | High | 3 | 1 |
| SANTA-4 | View Restaurant Applications | High | 3 | 1 |
| SANTA-5 | Document Verification | High | 3 | 1 |
| SANTA-6 | Application Approval | High | 2 | 1 |
| SANTA-7 | Application Rejection Notification | Medium | 3 | 2 |
| SANTA-8 | Document Re-upload | Medium | 2 | 2 |

## Process flow

![Merchant onboarding flow](diagrams/merchant-onboarding-flow.png)

## What I learned

Requirement gathering, process mapping, writing user stories and acceptance criteria, sprint planning, requirements traceability, and using GenAI to draft and then review documentation.

## Author

Santhosh A
